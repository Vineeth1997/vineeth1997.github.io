﻿using System;
using System.Collections.Generic;
using FDS_ModelLibrary;
using FDS_DALLibrary;

namespace FDS_BLLibrary
{
  public   class FDS_BL
    {
        FDS_DAL dal;
        FDS_DAL dal1;
        List<FDS> fdss;
        List<FDS> fdsblogs;
        public FDS_BL()
        {
            dal = new FDS_DAL();
            dal1 = new FDS_DAL();
        }
        public List<FDS> GetAllUsersDetail()
        {
            fdss = dal.GetUserDetailsFromDatabase();
            return fdss;
        }
        public List<FDS> GetAllBlogDetail()
        {
            fdsblogs = dal1.GetBlogDetailsFromdatabase();
            return fdsblogs;
        }
        public bool InsertUser(FDS fds)
        {
            bool bResult = false;
            GetAllUsersDetail();
            Predicate<FDS> checkFDS = f => f.User_id == fds.User_id;
            if (fdss.Find(checkFDS) == null)
            {
                if (dal.InsertUserDetailsintodb(fds))
                    bResult = true;
            }
            else
                throw new Duplicate_FDS_Exception();
            return bResult;
        }
        public bool InsertBlog(FDS fds)
        {
            bool bResult = false;
            GetAllBlogDetail();
            Predicate<FDS> checkFDS = f => f.Blog_title == fds.Blog_title;
            if (fdsblogs.Find(checkFDS) == null)
            {
                if (dal.InsertBlogsDetailsintodb(fds))
                    bResult = true;
            }
           
            return bResult;  
        }
        public bool LoginSuccess(FDS fds)
        {
            bool result = false;
            GetAllUsersDetail();
            Predicate<FDS> checkuserid = f => f.User_id == fds.User_id;
            Predicate<FDS> checkpassword = f => f.Password == fds.Password;
            Predicate<FDS> checkrole = f => f.Role == fds.Role;
            if (fdss.Find(checkuserid) != null && fdss.Find(checkpassword) != null)
            {
                result = true;
            }
            return result;
        }
        public bool deleteblog(FDS fds)
        {
            bool b_result = false;
            GetAllBlogDetail();
            foreach (FDS f in fdsblogs)
            {
                if (f.Blog_title == fds.Blog_title)
                {
                    fdsblogs.Remove(f);
                    b_result = true;
                }
            }
            return b_result;
        }
       
    }
}