﻿using System;
using System.Collections.Generic;

using System.Threading.Tasks;

namespace FDS_ModelLibrary
{
    public class Duplicate_FDS_Exception : ApplicationException
    {
        string errormsg;
        public Duplicate_FDS_Exception()
        {
            errormsg = "User id already exist";
        }
        public Duplicate_FDS_Exception(string s)
        {
            errormsg = s + "User id already exists";
        }
        public override string Message
        {
            get
            {
                return errormsg;
            }
        }
    }
}
