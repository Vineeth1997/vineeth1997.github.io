﻿using System;
using System.Collections.Generic;
using System.Drawing;


namespace FDS_ModelLibrary
{
    public class FDS : IComparable<FDS>
    {
        int user_id, age;
        string first_name, last_name, password, role, contact_number, organization, city, blog_title, blog_description, created_by;
        byte[] img;

        public byte[] Img
        {
            get { return img; }
            set { img = value; }
        }

       
        public string Created_by
        {
            get { return created_by; }
            set { created_by = value; }
        }

        public string Blog_description
        {
            get { return blog_description; }
            set { blog_description = value; }
        }

        public string Blog_title
        {
            get { return blog_title; }
            set { blog_title = value; }
        }
      
        
        
        public string City
        {
            get { return city; }
            set { city = value; }
        }

        public string Organization
        {
            get { return organization; }
            set { organization = value; }
        }



        public string Role
        {
            get { return role; }
            set { role = value; }
        }

        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        public string Last_name
        {
            get { return last_name; }
            set { last_name = value; }
        }

        public string First_name
        {
            get { return first_name; }
            set { first_name = value; }
        }
        public string Contact_number
        {
            get { return contact_number; }
            set { contact_number = value; }
        }

        public int User_id
        {
            get { return user_id; }
            set { user_id = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }
        public FDS() { }
        public FDS(int user_id, int age, string contact_number, string first_name, string last_name, string password, string role,string organization,string city)
        {
            this.user_id = user_id;
            this.age = age;
            this.contact_number = contact_number;
            this.first_name = first_name;
            this.last_name = last_name;
            this.password = password;
            this.role = role;
            this.organization = organization;
            this.city = city;

        }
        public FDS(string title, string description, string createdby, byte[] img1)
        {
            this.blog_title = title;
            this.blog_description = description;
            this.created_by = createdby;
            this.img = img1;
        }
        public int CompareTo(FDS fds)
        {
            return this.User_id.CompareTo(fds.User_id);
        }
    }

}
