﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using FDS_ModelLibrary;
using System.Configuration;
using System.Drawing;

namespace FDS_DALLibrary
{
    public class FDS_DAL
    {
        SqlConnection con;
        SqlDataAdapter daFDS;
        SqlDataAdapter daFDsblog;
        SqlCommand cmdInsertUserdetails,cmdblogs;
        public FDS_DAL()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["conFDS"].ConnectionString);
            daFDS = new SqlDataAdapter("GET_USER_DETAILS", con);
            daFDS.SelectCommand.CommandType = CommandType.StoredProcedure;
            cmdInsertUserdetails = new SqlCommand("Insert_into_User_Reg",con);
            //cmdInsertUserdetails.Connection = con;
            cmdInsertUserdetails.CommandType = CommandType.StoredProcedure;
            cmdInsertUserdetails.Parameters.Add("@user_idn", SqlDbType.Int);
            cmdInsertUserdetails.Parameters.Add("@firstname", SqlDbType.VarChar, 50);
            cmdInsertUserdetails.Parameters.Add("@lastname", SqlDbType.VarChar, 50);
            cmdInsertUserdetails.Parameters.Add("@age", SqlDbType.Int);
            cmdInsertUserdetails.Parameters.Add("@contactnumber", SqlDbType.VarChar,10);
            cmdInsertUserdetails.Parameters.Add("@userpassword", SqlDbType.VarChar, 20);
            cmdInsertUserdetails.Parameters.Add("@user_role", SqlDbType.VarChar, 50);
            cmdInsertUserdetails.Parameters.Add("@organization", SqlDbType.VarChar, 20);
            cmdInsertUserdetails.Parameters.Add("@city", SqlDbType.VarChar, 20);
            daFDsblog = new SqlDataAdapter("GetBlogDetails", con);
            daFDsblog.SelectCommand.CommandType = CommandType.StoredProcedure;
            cmdblogs = new SqlCommand("proc_blog", con);
            cmdblogs.CommandType = CommandType.StoredProcedure;
            cmdblogs.Parameters.Add("@Blog_title", SqlDbType.VarChar, 50);
            cmdblogs.Parameters.Add("@Blog_description", SqlDbType.VarChar, 200);
            cmdblogs.Parameters.Add("@Created_by", SqlDbType.VarChar, 100);
            cmdblogs.Parameters.Add("@Blog_image", SqlDbType.VarBinary);

        }
        public List<FDS> GetUserDetailsFromDatabase()
        {
            List<FDS> FDSs = new List<FDS>();
            DataSet dsFDS = new DataSet();
            daFDS.Fill(dsFDS);
            FDS fds;
            foreach (DataRow dr in dsFDS.Tables[0].Rows)
            {
                fds = new FDS();
                fds.User_id = int.Parse(dr[0].ToString());
                fds.First_name = dr[1].ToString();
                fds.Last_name = dr[2].ToString();
                fds.Age = int.Parse(dr[3].ToString());
                fds.Contact_number = dr[4].ToString();
                fds.Password = dr[5].ToString();
                fds.Role = dr[6].ToString();
                fds.Organization = dr[7].ToString();
                fds.City = dr[8].ToString();
                FDSs.Add(fds);
            }
            return FDSs;
        }
        public List<FDS> GetBlogDetailsFromdatabase()
        {
           List<FDS> FDSblogs = new List<FDS>();
            DataSet dsFDSblog = new DataSet();
            daFDsblog.Fill(dsFDSblog);
            FDS fds;
            foreach (DataRow dr in dsFDSblog.Tables[0].Rows)
            {
                fds = new FDS();
                fds.Blog_title = dr[0].ToString();
                fds.Blog_description = dr[1].ToString();
                fds.Created_by = dr[2].ToString();
                fds.Img =(byte[]) (dr[3]);
            }
            return FDSblogs;
        }
        public bool InsertUserDetailsintodb(FDS fds)
        {
            bool b_Result = false;
            cmdInsertUserdetails.Parameters[0].Value = fds.User_id;
            cmdInsertUserdetails.Parameters[1].Value = fds.First_name;
            cmdInsertUserdetails.Parameters[2].Value = fds.Last_name;
            cmdInsertUserdetails.Parameters[3].Value = fds.Age;
            cmdInsertUserdetails.Parameters[4].Value = fds.Contact_number;
            cmdInsertUserdetails.Parameters[5].Value = fds.Password;
            cmdInsertUserdetails.Parameters[6].Value = fds.Role;
            cmdInsertUserdetails.Parameters[7].Value = fds.Organization;
            cmdInsertUserdetails.Parameters[8].Value = fds.City;
            if (con.State == ConnectionState.Open)
                con.Close();
            con.Open();
            int _iresult = cmdInsertUserdetails.ExecuteNonQuery();
            if (_iresult == 1)
                b_Result = true;
            con.Close();
            return b_Result;
        }
        public bool InsertBlogsDetailsintodb(FDS fds)
        {
            bool b1_Result = false;
            cmdblogs.Parameters[0].Value = fds.Blog_title;
            cmdblogs.Parameters[1].Value = fds.Blog_description;
            cmdblogs.Parameters[2].Value = fds.Created_by;
            cmdblogs.Parameters[3].Value = fds.Img;
            if (con.State == ConnectionState.Open)
                con.Close();
            con.Open();
            int _iresult = cmdblogs.ExecuteNonQuery();
            if (_iresult == 1)
                b1_Result = true;
            con.Close();
            return b1_Result;

        }


    }
}
