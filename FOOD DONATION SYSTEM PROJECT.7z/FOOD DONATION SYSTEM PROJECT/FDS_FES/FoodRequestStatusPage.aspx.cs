﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FDS_BLLibrary;
using FDS_ModelLibrary;

namespace FDS_FES
{
    
    public partial class FoodRequestStatusPage : System.Web.UI.Page
    {
        FDS_BL bl;
        List<FDS> fdss;
        string message = "Rejected";
        protected void Page_Load(object sender, EventArgs e)
        {
            lblrequeststatus.Text = "Pending";
        }

       
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void btnupdated_Click1(object sender, EventArgs e)
        {
            bl = new FDS_BL();
            fdss = bl.GetAllUsersDetail();
            foreach (FDS f in fdss)
            {

                if (f.City == Request.Params["un"].ToString() && f.Role == "NGO")
                {
                    message = "Accepted";
                    break;
                }

            }

            lblrequeststatus.Text = message;
        }
          
        
    }
}