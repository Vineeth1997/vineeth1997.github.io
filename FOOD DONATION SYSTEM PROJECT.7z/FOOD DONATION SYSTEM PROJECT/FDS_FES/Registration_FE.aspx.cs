﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FDS_ModelLibrary;
using FDS_BLLibrary;
using System.Configuration;

namespace FDS_FE
{
    public partial class FDS_FE : System.Web.UI.Page
    {
        string message = "";
        FDS_BL bl = new FDS_BL();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            FDS fds = new FDS();
            fds.User_id = int.Parse(txtUserID.Text);
            fds.First_name = txtFirstName.Text;
            fds.Last_name = txtLastName.Text;
            fds.Age = int.Parse(txtAge.Text);
            fds.Contact_number =txtContactNumber.Text;
            fds.Password = txtPassword.Text;
            fds.Role = ddlrole.SelectedItem.Text;
            fds.Organization = txtOrganization.Text;
            fds.City = txtcity.Text;
            //try
            //{
                if (bl.InsertUser(fds) == true)
                {
                    message = "Registration Succesfull";
                }

            //}
            //catch (Duplicate_FDS_Exception dfe)
            //{
            //    message = dfe.Message;
            //}
            //catch (System.Data.SqlClient.SqlException se)
            //{
            //    message = se.Message;
            //}
            //catch (Exception ex)
            //{
            //    message = ex.Message;
            //}
            lblerror.Text = message;
            Response.Redirect("Login_FE.aspx");
        }
    }
} 