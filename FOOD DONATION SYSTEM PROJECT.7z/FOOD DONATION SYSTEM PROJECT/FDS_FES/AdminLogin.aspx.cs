﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FDS_FES
{
    public partial class AdminLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnadminlogin_Click(object sender, EventArgs e)
        {
            if (txtadminpassword.Text == "FDS2")
                Response.Redirect("AdminBlogpage.aspx");
            else
                lblloginerror.Text = "Wrong Password";
        }
    }
}