﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using FDS_BLLibrary;
using FDS_ModelLibrary;


namespace FDS_FES
{
    public partial class AdminBlogpage : System.Web.UI.Page
    {
       
        string message = "";
        FDS_BL bl = new FDS_BL();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                HttpPostedFile postedfile = FileUpload1.PostedFile;
                string filename = Path.GetFileName(postedfile.FileName);
                //string extension = Path.GetExtension(filename);
                //int filesize = postedfile.ContentLength;
                FDS fds = new FDS();
                Stream stream = postedfile.InputStream;
                BinaryReader br = new BinaryReader(stream);
                
                byte[] img = br.ReadBytes((int)stream.Length);
                //FileStream fs = new FileStream(FileUpload1.FileName, FileMode.Open, FileAccess.Read);
               
               
                fds.Blog_title = txtblogtitle.Text;
                fds.Blog_description = txtdescription.Text;
                fds.Created_by = txtcreatedby.Text;
                fds.Img = img;
                if (bl.InsertBlog(fds) == true)
                {
                    message = "Blog created successfully";
                }
                lblerrorblog.Text = message;
            }
            catch (Exception e1)
            {
                lblerrorblog.Text = e1.Message;
            }
        }

        protected void btndel_Click(object sender, EventArgs e)
        {FDS fds=new FDS();
            fds.Blog_title=txtblogtitle.Text;

            if (bl.deleteblog(fds))
            {
                lblerrorblog.Text = "Blog removed successfully";
            }
            else
                lblerrorblog.Text = "Blog Title not found";
        }

        
    }
}