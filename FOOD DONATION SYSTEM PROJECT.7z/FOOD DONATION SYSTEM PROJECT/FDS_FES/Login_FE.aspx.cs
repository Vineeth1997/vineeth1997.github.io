﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FDS_ModelLibrary;
using FDS_BLLibrary;
using System.Configuration;
namespace FDS_FES
{
    public partial class Login_FE : System.Web.UI.Page
    {
        FDS_BL bl; 
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            FDS fds = new FDS();
            fds.User_id = int.Parse(txtUserIDL.Text);
            fds.Password = txtPasswordL.Text;
            bl = new FDS_BL();
            bool bResult = bl.LoginSuccess(fds);
            if (bResult == true)
            {
                Session.Add("userid", txtUserIDL.Text);
               

                if (ddlrolelist.SelectedItem.Text == "NGO")
                    Response.Redirect("NGO_FE.aspx");
                else if (ddlrolelist.SelectedItem.Text == "User")
                    Response.Redirect("Blog.aspx");
            }
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration_FE.aspx");
        }

       
    }
}